from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from etl.ingest.detect_header import detect_header
from etl.ingest.map_columns import map_columns


def drop_fully_empty_rows_and_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove rows and columns that are completely empty.
    """
    cleaned_df = df.dropna(axis=0, how="all").dropna(axis=1, how="all")
    return cleaned_df


def build_dataframe_from_detected_header(
    raw_df: pd.DataFrame,
    header_row_index: int,
) -> pd.DataFrame:
    """
    Build a clean dataframe using the detected header row.

    Steps:
    - take header values from the detected row
    - take data from the rows below
    - assign detected header as columns
    - reset index
    - drop fully empty rows/columns
    """
    header_values = raw_df.iloc[header_row_index].tolist()
    data_df = raw_df.iloc[header_row_index + 1 :].copy()

    data_df.columns = header_values
    data_df = data_df.reset_index(drop=True)
    data_df = drop_fully_empty_rows_and_columns(data_df)

    return data_df


def add_source_row_number(
    df: pd.DataFrame,
    header_row_index: int,
) -> pd.DataFrame:
    """
    Add the original row number from the source file.

    This is useful for traceability and debugging.
    """
    result_df = df.copy()

    # Excel row number considering:
    # - pandas index starts at 0
    # - header row occupies one row in the source file
    # - Excel-style human-readable numbering starts at 1
    result_df["source_row_number"] = range(header_row_index + 2, header_row_index + 2 + len(result_df))

    return result_df


def read_excel_file(
    file_path: str | Path,
    sheet_name: str | int = 0,
    mapping_path: str | Path = "etl/config/column_mapping.yml",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Read an Excel file, detect the header row automatically,
    rebuild the dataframe with the detected header,
    map columns to the internal standard schema,
    and return both the dataframe and debug info.

    Parameters
    ----------
    file_path : str | Path
        Path to the Excel file.
    sheet_name : str | int
        Excel sheet name or index.
    mapping_path : str | Path
        Path to the column mapping YAML file.

    Returns
    -------
    tuple[pd.DataFrame, dict[str, Any]]
        processed_df,
        debug_info
    """
    file_path = Path(file_path)

    raw_df = pd.read_excel(
        file_path,
        sheet_name=sheet_name,
        header=None,
        dtype=object,
    )

    header_row_index, header_debug = detect_header(
        raw_df=raw_df,
        mapping_path=mapping_path,
    )

    structured_df = build_dataframe_from_detected_header(
        raw_df=raw_df,
        header_row_index=header_row_index,
    )

    structured_df = add_source_row_number(
        df=structured_df,
        header_row_index=header_row_index,
    )

    mapped_df, mapping_debug = map_columns(
        df=structured_df,
        mapping_path=mapping_path,
    )

    debug_info = {
        "file_path": str(file_path),
        "sheet_name": sheet_name,
        "header_detection": header_debug,
        "column_mapping": mapping_debug,
        "raw_shape": raw_df.shape,
        "structured_shape": structured_df.shape,
        "mapped_shape": mapped_df.shape,
    }

    return mapped_df, debug_info