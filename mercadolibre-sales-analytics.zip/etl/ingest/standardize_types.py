from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import yaml


def load_schema_definition(schema_definition_path: str | Path) -> dict[str, str]:
    """
    Load schema definition from YAML.

    Expected structure:
    schema:
      sale_id: string
      sale_date: date
      quantity: int64
      total_amount_ars: float64
      loaded_at: datetime
    """
    schema_definition_path = Path(schema_definition_path)

    with schema_definition_path.open("r", encoding="utf-8") as file:
        config = yaml.safe_load(file) or {}

    return config.get("schema", {})


def standardize_string(series: pd.Series) -> pd.Series:
    """
    Convert values to pandas StringDtype, preserving nulls.
    """
    return series.astype("string").str.strip()


def standardize_int64(series: pd.Series) -> pd.Series:
    """
    Convert values to nullable Int64 dtype.
    """
    numeric_series = pd.to_numeric(series, errors="coerce")
    return numeric_series.astype("Int64")


def standardize_float64(series: pd.Series) -> pd.Series:
    """
    Convert values to float64.
    """
    return pd.to_numeric(series, errors="coerce").astype("float64")


def standardize_date(series: pd.Series) -> pd.Series:
    """
    Convert values to date.

    Returned dtype will usually be object with Python date values,
    which is acceptable before loading into BigQuery.
    """
    datetime_series = pd.to_datetime(series, errors="coerce")
    return datetime_series.dt.date


def standardize_datetime(series: pd.Series) -> pd.Series:
    """
    Convert values to pandas datetime64[ns].
    """
    return pd.to_datetime(series, errors="coerce")


def standardize_column(series: pd.Series, target_type: str) -> pd.Series:
    """
    Dispatch column conversion based on target type from schema YAML.
    """
    if target_type == "string":
        return standardize_string(series)

    if target_type == "int64":
        return standardize_int64(series)

    if target_type == "float64":
        return standardize_float64(series)

    if target_type == "date":
        return standardize_date(series)

    if target_type == "datetime":
        return standardize_datetime(series)

    raise ValueError(f"Unsupported target type in schema_definition.yml: {target_type}")


def standardize_types(
    df: pd.DataFrame,
    schema_definition_path: str | Path = "etl/config/schema_definition.yml",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Standardize dataframe column types according to schema_definition.yml.

    Rules:
    - only columns present in the dataframe are standardized
    - missing schema columns are ignored here
    - returns transformed dataframe + debug info
    """
    schema_definition = load_schema_definition(schema_definition_path)

    standardized_df = df.copy()

    converted_columns: dict[str, str] = {}
    skipped_columns: list[str] = []
    conversion_errors: dict[str, str] = {}

    for column_name, target_type in schema_definition.items():
        if column_name not in standardized_df.columns:
            skipped_columns.append(column_name)
            continue

        try:
            standardized_df[column_name] = standardize_column(
                standardized_df[column_name],
                target_type=target_type,
            )
            converted_columns[column_name] = target_type
        except Exception as exc:
            conversion_errors[column_name] = str(exc)

    debug_info = {
        "converted_columns": converted_columns,
        "skipped_columns": skipped_columns,
        "conversion_errors": conversion_errors,
        "result_dtypes": {
            column: str(dtype) for column, dtype in standardized_df.dtypes.items()
        },
    }

    if conversion_errors:
        raise ValueError(
            "Type standardization failed for one or more columns: "
            f"{conversion_errors}"
        )

    return standardized_df, debug_info